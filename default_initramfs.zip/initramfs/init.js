(function(ctx, $kernel) {
    $kernel.bindings.sda1 = ctx.driveTypes.localStorage('sda1');
    $kernel.gui_init($kernel.tHandle);
})